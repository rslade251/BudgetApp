package com.example.recyclerview

data class News(var titleImage: Int, var heading: String)
